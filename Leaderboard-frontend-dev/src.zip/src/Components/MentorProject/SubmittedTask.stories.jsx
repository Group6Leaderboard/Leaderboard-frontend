import SubmittedTask from './SubmittedTask';

const meta = {
  component: SubmittedTask,
};

export default meta;

export const Default = {
  args: {}
};
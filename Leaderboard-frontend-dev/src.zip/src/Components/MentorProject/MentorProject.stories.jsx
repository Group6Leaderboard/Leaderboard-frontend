import MentorProject from './MentorProject';

const meta = {
  component: MentorProject,
};

export default meta;

export const Default = {
  args: {}
};
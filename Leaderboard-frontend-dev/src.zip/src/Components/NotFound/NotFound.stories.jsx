import NotFound from './NotFound';

const meta = {
  component: NotFound,
};

export default meta;

export const Default = {
  args: {}
};
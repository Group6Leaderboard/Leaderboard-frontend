import React from "react";


export default {
  title: "Components/Calender/Calender",
  component: Calender,
};

const Template = (args) => <Calender {...args} />;

export const Default = Template.bind({});
Default.args = {};

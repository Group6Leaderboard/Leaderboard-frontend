import React from "react";

const CollegeDashboard = () => {
  return <h2>Welcome to College Dashboard</h2>;
};

export default CollegeDashboard;

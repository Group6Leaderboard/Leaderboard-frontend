// import React from "react";
// import Sidebar from "../Components/Sidebar/Sidebar";
// import Navbar from "../Components/Navbar/Navbar";
// import styles from "../Components/Navbar/Navbar";

// const Layout = ({ children }) => {
//   return (
//     <div className={styles.layoutContainer}>
//       {/* Sidebar - Always Visible */}
//       <Sidebar />

//       {/* Main Content with Navbar */}
//       <div className={styles.mainContent}>
//         <Navbar />
//         <div className={styles.pageContent}>{children}</div>
//       </div>
//     </div>
//   );
// };

// export default Layout;
